﻿# TCM-Flow 数据集归档

## 📦 内容说明

| 文件 | 大小 | 说明 |
|------|------|------|
| tcm.db | ~100 MB | 中药活性成分数据库（SQLite 格式） |

## 📊 数据库内容

- **中药数量**：3,819 味
- **活性成分数量**：7,284 种
- **靶点信息**：成分-靶点对应关系
- **通路信息**：KEGG 通路富集数据

## 🔍 数据库表结构

### herbs 中药表
- id, name_cn, name_pinyin, nature, flavor, meridians, indications

### compounds 活性成分表
- id, name_cn, name_en, cas, molecular_formula, molecular_weight, smiles, ob, dl, has_structure

### targets 靶点表
- id, gene_name, protein_name, uniprot_id

### compound_targets 成分-靶点关联表
- id, compound_id, target_id

### pathways 通路表
- id, pathway_id, pathway_name, category

### compound_pathways 成分-通路关联表
- id, compound_id, pathway_id, p_value, gene_count

## 🚀 使用方法

### 方法一：环境变量（推荐）
`ash
# Windows
set TCMFLOW_DB_PATH=C:\path\to\tcm.db

# Linux / macOS
export TCMFLOW_DB_PATH=/path/to/tcm.db
`

### 方法二：直接放入 data 目录
将 tcm.db 复制到 TCM-Flow 核心平台的 data/ 目录下。

## 📝 数据来源

- 中药信息：TCMSP、TCMID、BATMAN-TCM 等数据库整合
- 活性成分筛选标准：OB ≥ 30% 且 DL ≥ 0.18
- 靶点预测：SwissTargetPrediction、PharmMapper 等
- 通路富集：KEGG PATHWAY 数据库

## 📌 注意事项

1. 本数据库仅供科研使用，不得用于商业用途
2. 数据整合自多个公开数据库，如有不准确之处以原始数据库为准
3. 如数据库有更新，将在 GitHub Release 中发布

## 📄 引用

如使用本数据集，请引用 TCM-Flow 论文。
